package com.colak.springnettytutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringNettyTutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
