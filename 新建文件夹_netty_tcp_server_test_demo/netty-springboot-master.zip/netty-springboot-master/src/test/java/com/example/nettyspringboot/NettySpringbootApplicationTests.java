package com.example.nettyspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NettySpringbootApplicationTests {

    @Test
    void contextLoads() {
    }

}
