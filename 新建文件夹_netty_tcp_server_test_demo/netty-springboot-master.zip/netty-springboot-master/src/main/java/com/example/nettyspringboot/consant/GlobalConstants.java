package com.example.nettyspringboot.consant;

public class GlobalConstants {
    /** 服务器线程数  */
    public static  int SERVER_THREAD_COUNT = 200;
}
