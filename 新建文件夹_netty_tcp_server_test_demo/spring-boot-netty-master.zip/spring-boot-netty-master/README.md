# spring-boot-netty
Sample Spring Boot application using Netty Application Server
