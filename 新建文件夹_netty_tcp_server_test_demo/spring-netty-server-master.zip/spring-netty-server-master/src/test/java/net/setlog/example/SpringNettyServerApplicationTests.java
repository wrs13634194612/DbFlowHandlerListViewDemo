package net.setlog.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringNettyServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
