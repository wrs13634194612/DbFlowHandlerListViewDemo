package com.interview.sports.weather.netty.request;

public record VenueWeatherRequest(String venue) { }
