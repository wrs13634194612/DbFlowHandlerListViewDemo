package com.interview.sports.weather.controller.response;

public record Stadium(String id, String name, String link, Location location, boolean active) { }
