package com.interview.sports.weather.netty.response;

public interface WeatherResponse {
    void setMessage(String message);
}
