package com.interview.sports.weather;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportsWeatherApplication {

    public static void main(String[] args) {
        SpringApplication.run(SportsWeatherApplication.class, args);
    }

}
