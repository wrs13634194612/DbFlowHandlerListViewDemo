package com.interview.sports.weather.controller.response;

import java.util.List;

public record StadiumEvent(List<Stadium> venues) { }
