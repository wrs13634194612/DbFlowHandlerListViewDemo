package com.interview.sports.weather.controller.response;

public record DefaultCoordinates(String latitude, String longitude) {
}
