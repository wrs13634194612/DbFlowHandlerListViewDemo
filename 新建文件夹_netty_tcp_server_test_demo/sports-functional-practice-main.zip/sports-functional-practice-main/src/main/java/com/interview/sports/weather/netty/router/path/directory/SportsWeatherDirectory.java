package com.interview.sports.weather.netty.router.path.directory;

public class SportsWeatherDirectory {
    public static final String SPORTS_VENUE_WEATHER_ENDPOINT = "/sport/weather/venue";
    public static final String SPORTS_TEAM_WEATHER_ENDPOINT = "/sport/weather/team";
}
