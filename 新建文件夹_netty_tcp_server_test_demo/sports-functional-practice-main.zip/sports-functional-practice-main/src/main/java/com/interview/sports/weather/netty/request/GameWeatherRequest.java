package com.interview.sports.weather.netty.request;

public record GameWeatherRequest(String team, String date){ }
