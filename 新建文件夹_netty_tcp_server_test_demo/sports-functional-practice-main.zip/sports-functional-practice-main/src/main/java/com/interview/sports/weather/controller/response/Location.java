package com.interview.sports.weather.controller.response;

public record Location(String address1, String city, String state, String postalCode, DefaultCoordinates defaultCoordinates){
}
