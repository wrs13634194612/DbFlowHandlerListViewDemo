package com.interview.sports.weather;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportsWeatherApplicationTests {

    @Test
    void contextLoads() {
    }

}
