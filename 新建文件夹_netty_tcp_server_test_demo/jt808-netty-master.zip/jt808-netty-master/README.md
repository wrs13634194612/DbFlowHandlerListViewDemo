
这是一个Netty入门教学项目，解析JT808协议，整合Spring boot，并提供了一些Netty中的最佳实践（详细教程在下方连接）。


下载代码到本地后，改动application.yml中的数据库连接即可运行，搭载Spring Data JPA会自动建表，
然后通过 NetAssist网络调试工具.exe 以及 测试报文.txt 中的报文即可调试。

有问题欢迎提issue，如果对你有帮助麻烦给个Star鼓励一下 :)


<a href="https://juejin.im/post/5cde451f51882525fd1f6e68#heading-10">Netty实战之使用Netty解析交通部JT808协议</a>

![image](https://user-images.githubusercontent.com/50564542/173286593-abd16409-503f-4b3d-b270-47d9ac164fe5.png)
