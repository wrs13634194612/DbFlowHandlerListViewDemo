package com.digiwin.ltgx.domain;

import lombok.Data;


@Data
public class QueryVehicleCommonDetail {
    //PROD_STATUS，TIME_INFO
    private double VEHICLECAPACITY;
    private String VEHICLENO;
    private String RISKSTATUS;
}
