package com.digiwin.ltgx.domain;

import lombok.Data;


@Data
public class ProductionTaskInMESDetail {
    //BASELOTNO
    private String BASELOTNO;
}
