package com.digiwin.ltgx.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class QStatusProductionTaskDetail {
    //STATUS,COMBINEDTAG,UNITNO,UNITNAME,MOUNITNO,LOTNO,QTY,FINISHTIME,MONO,HOTLOT,OPNO,
    // LOTSTAMP,SEQ, OPNAME,PRODUCTNAME,ITEMSPEC,DISPATCH_QTY,ARRIVETIME, PRODUCTNO,WORKDATE,
    // HAVE_SUBOP,PLUGIN ,DOUBLEUNITQTY
    private String STATUS;
    private String COMBINEDTAG;
    private String UNITNO;
    private String UNITNAME;
    private String MOUNITNO;
    private String LOTNO;
    private String QTY;
    private String FINISHTIME;
    private String MONO;
    private String HOTLOT;
    private String OPNO;
    private String LOTSTAMP;
    private String SEQ;
    private String OPNAME;
    private String PRODUCTNAME;
    private String ITEMSPEC;
    private String DISPATCHQTY;
    private String ARRIVETIME;
    private String PRODUCTNO;
    private String WORKDATE;
    private String HAVESUBOP;
    private String PLUGIN ;
    private String DOUBLEUNITQTY;

}
