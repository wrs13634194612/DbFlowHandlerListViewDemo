package com.digiwin.ltgx.domain;

import lombok.Data;


@Data
public class QuerySNnoByLotnoOpnoVehicleNoDetail {
    //PRODUCTION_SN
    private String PRSN;

}
