package com.digiwin.ltgx.domain;

import lombok.Data;


@Data
public class QueryVehicleStatusDetail {
    //PROD_STATUS，TIME_INFO
    private String PRODSTATUS;
    private String TIMEINFO;
}
