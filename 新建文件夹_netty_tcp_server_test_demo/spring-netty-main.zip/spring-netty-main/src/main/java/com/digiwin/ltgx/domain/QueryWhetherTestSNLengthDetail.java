package com.digiwin.ltgx.domain;

import lombok.Data;


@Data
public class QueryWhetherTestSNLengthDetail {
    //PROD_STATUS，TIME_INFO
    private String OPNO;
    private String ISVERIFY;
    private String ISVERIFYVALUE;
}
