package com.digiwin.ltgx.config;

public class Config {
    public static boolean enable_http_detail_metrics = true;
    public static int http_backlog_num = 1024;
    public static int http_worker_threads_num = 0;
}
