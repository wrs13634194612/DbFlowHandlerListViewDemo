package com.digiwin.ltgx.domain;

import lombok.Data;


@Data
public class QueryRStatusTask {
    //PROD_STATUS，TIME_INFO
    private String OPNO;
    private String QTY;
}
