package com.digiwin.ltgx.domain;

import lombok.Data;


@Data
public class QueryVehicleBindSNDetail {

    private String plotno;
    private String opno;
    private String sn;
    private String width;
    private String location;
    private String remark1;
    private String remark2;

    /*private String OPNO;
    private String LOTNO;
    private String VEHICLENO;
    private String VEHICLENAME;
    private double VEHICLECAPACITY;
    private String PRODUCTIONSN;
    private String PRODUCTIONLOCATION;
    private String PRODUCTIONWIDTH;
    private String USERDEFINED01;
    private String USERDEFINED02;
    private String RISKSTATUS;
    private String PLF;
    private String PLL;*/

}
